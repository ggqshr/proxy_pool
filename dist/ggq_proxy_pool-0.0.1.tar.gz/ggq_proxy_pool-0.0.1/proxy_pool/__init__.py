from .ip_pool import IpPool
name = "ggq_proxy_pool"
